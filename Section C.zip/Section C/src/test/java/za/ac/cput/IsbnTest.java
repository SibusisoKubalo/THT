package za.ac.cput;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IsbnTest {
    static Isbn isbn = new Isbn();

    @Test
    void isISBN_10() {
        assertTrue(isbn.isISBN_10("0330301624"));
    }

    @Test
    void isISBN_13() {
        assertTrue(isbn.isISBN_13("9780316066525"));
    }

    @Test
    void isValidIBN() {
        assertEquals("Valid", isbn.isValidIBN("9780316066525"));
        assertEquals("Invalid", isbn.isValidIBN("978031606652"));
        assertEquals("9870316066523", isbn.isValidIBN("0316066524"));
    }
}