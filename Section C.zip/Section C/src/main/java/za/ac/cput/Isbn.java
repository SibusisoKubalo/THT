package za.ac.cput;

public class Isbn {

    public static boolean isISBN_10(String isbn){
        int sum = 0;
        if(isbn.length() != 10)
            return false;
        for(int i = 1; i <= 10; i++){
            try{
                if(i == 10 && isbn.charAt(i-1) == 'X'){
                    sum += 10 * (11 - i);
                }
                else{
                    sum += Integer.parseInt(isbn.substring(i-1, i)) * (11 - i);
                }
            }
            catch (NumberFormatException e) {
                return false;
            }
        }
        return sum % 11 == 0;
    }

    public static boolean isISBN_13(String isbn){
        int sum = 0;
        int val;
        if(isbn.length() != 13)
            return false;
        for(int i = 1; i <= 13; i++){
            try{
                if(i % 2 == 0)
                    val = 3;
                else
                    val = 1;
                sum += Integer.parseInt(isbn.substring(i-1, i)) * val;
            }
            catch (NumberFormatException e) {
                return false;
            }
        }
        return sum % 10 == 0;
    }

    public static String isValidIBN(String isbn){
        boolean is10 = isISBN_10(isbn);
        boolean is13 = isISBN_13(isbn);
        String newISBN;
        int count;
        if(!is10 && !is13){
            return "Invalid";
        }
        else if(is13){
            return "Valid";
        }
        else{
            newISBN = "987"+isbn;
            count = 1;
            while(!isISBN_13(newISBN)){
                newISBN = newISBN.substring(0, newISBN.length() - 1)+count;
                count ++;
            }
            return newISBN;
        }
    }
}
